﻿Public Class Form1
    Dim cf As Form

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        OpenChildForm(New Home)


        salesbtn.Enabled = False
        expensesbtn.Enabled = False
        databasebtn.Enabled = False
        purchasesbtn.Enabled = False
        signoutbtn.Enabled = False
    End Sub
    Public Sub OpenChildForm(childForm As Form)
        If cf IsNot Nothing Then
            cf.Close()

        End If
        cf = childForm
        childForm.TopLevel = False
        childForm.FormBorderStyle = FormBorderStyle.None
        childForm.Dock = DockStyle.Fill
        Panel1.Controls.Add(childForm)

        childForm.BringToFront()
        childForm.Show()
    End Sub




    Private Sub loginbtn_Click_1(sender As Object, e As EventArgs) Handles loginbtn.Click
        OpenChildForm(New Login)
    End Sub

    Private Sub homebtn_Click(sender As Object, e As EventArgs) Handles homebtn.Click
        OpenChildForm(New Home)
    End Sub

    Private Sub salesbtn_Click(sender As Object, e As EventArgs) Handles salesbtn.Click
        OpenChildForm(New Sales)
    End Sub

    Private Sub purchasesbtn_Click(sender As Object, e As EventArgs) Handles purchasesbtn.Click
        OpenChildForm(New Purchases)
    End Sub

    Private Sub databasebtn_Click(sender As Object, e As EventArgs) Handles databasebtn.Click
        OpenChildForm(New Database)
    End Sub

    Private Sub expensesbtn_Click(sender As Object, e As EventArgs) Handles expensesbtn.Click
        OpenChildForm(New Expenses)
    End Sub

    Private Sub signoutbtn_Click_1(sender As Object, e As EventArgs) Handles signoutbtn.Click
        Login.Enabled = True
        salesbtn.Enabled = False
        expensesbtn.Enabled = False
        databasebtn.Enabled = False
        purchasesbtn.Enabled = False
        loginbtn.Enabled = True
        signoutbtn.Enabled = False
        homebtn.Enabled = True

        OpenChildForm(New Login)
    End Sub
End Class
