﻿Imports System.Data.SqlClient
Imports System.Data
Public Class admindatabase
    Dim con As New SqlConnection("Server= rip; Database = mobileapp; Integrated Security = true")
    Dim cmd As New SqlCommand
    Private Sub admindatabase_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        If con.State = ConnectionState.Open Then
            onofflbl.Text = "ON"
        Else
            onofflbl.Text = "off"
        End If
        disp_data("")
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        If con.State = ConnectionState.Open Then
            onofflbl.Text = "ON"
        Else
            onofflbl.Text = "off"
        End If
        Try
            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = " INSERT INTO [dbo].[admin]
           ([ID]
           ,[Username]
           ,[password]
           ,[Address]
           ,[Contact_No])
     VALUES('" + aidtxt.Text + "','" + ausernametxt.Text + "','" + apasswordtxt.Text + "','" + aaddresstxt.Text + "','" + acontactnotxt.Text + "')"
            cmd.ExecuteNonQuery()

            MessageBox.Show("an admin created successfully")
        Catch ex As Exception
            MsgBox("input data error,plz input the valid data")
        End Try
        disp_data("")
        con.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        If con.State = ConnectionState.Open Then
            onofflbl.Text = "ON"
        Else
            onofflbl.Text = "off"
        End If
        Try
            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "UPDATE [dbo].[admin]
   SET [ID] ='" + aidtxt.Text + "'
      ,[Username] ='" + ausernametxt.Text + "'
      ,[password] = '" + apasswordtxt.Text + "'
      ,[Address] = '" + aaddresstxt.Text + "'
      ,[Contact_No] = '" + acontactnotxt.Text + "'
 WHERE [ID] ='" + aidtxt.Text + "'"
            cmd.ExecuteNonQuery()

            MessageBox.Show("Admin data Updated Successfully")
        Catch ex As Exception
            MsgBox("input data error, plz input the valid data")
        End Try
        disp_data("")
        con.Close()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        If con.State = ConnectionState.Open Then
            onofflbl.Text = "ON"
        Else
            onofflbl.Text = "off"
        End If

        Try
            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "select * from [dbo].[admin] where [ID]='" + asearchtxt.Text + "'"
            cmd.ExecuteNonQuery()
            Dim sda As New SqlDataAdapter(cmd)
            Dim dt As New DataTable()
            sda.Fill(dt)
            If dt.Rows.Count > 0 Then
                aidtxt.Text = dt.Rows(0)(0).ToString()
                ausernametxt.Text = dt.Rows(0)(1).ToString()
                apasswordtxt.Text = dt.Rows(0)(2).ToString()
                aaddresstxt.Text = dt.Rows(0)(3).ToString()
                acontactnotxt.Text = dt.Rows(0)(4).ToString()

            End If
        Catch ex As Exception
            MsgBox("plz enter the correct ID")
        End Try
        disp_data("")
        con.Close()
    End Sub
    Public Sub disp_data(ds As String)
        Dim cmd As New SqlCommand("select *  from admin where concat(ID,Username,password,Address,Contact_No) Like '%" & ds & "%' ", con)
        Dim da As New SqlDataAdapter(cmd)
        Dim dt As New DataTable()
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        Try
            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "DELETE From [dbo].[admin]
      Where [ID] ='" + asearchtxt.Text + "' "
            cmd.ExecuteNonQuery()

            MessageBox.Show("an Admin is deleted")
        Catch ex As Exception
            MsgBox("ID error, please input valid ID")
        End Try
        disp_data("")
        con.Close()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        disp_data(asearchtxt.Text)
    End Sub
End Class