﻿Imports System.Data.SqlClient
Imports System.Data
Public Class Login
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim connection As New SqlConnection("Server= rip; Database = mobileapp; Integrated Security = true")

        Try
            Dim command As New SqlCommand("select * from admin where Username = @username and Password = @password", connection)

            command.Parameters.Add("@username", SqlDbType.VarChar).Value = unametxt.Text
            command.Parameters.Add("@password", SqlDbType.VarChar).Value = passtxt.Text

            Dim adapter As New SqlDataAdapter(command)

            Dim table As New DataTable()

            adapter.Fill(table)

            If table.Rows.Count() <= 0 Then

                MsgBox("Admin cann't be verified, Please check your username and password ")
            ElseIf unametxt.Text = "" Or passtxt.Text = "" Then
                MsgBox("username or password cannot be empty")
            Else
                Timer1.Enabled = True

                MsgBox("admin Authentication successful")
                Form1.OpenChildForm(New Home)
                ProgressBar1.Value = 0
                unametxt.Text = ""
                passtxt.Text = ""
                Form1.loginbtn.Enabled = False
                Form1.salesbtn.Enabled = True
                Form1.expensesbtn.Enabled = True
                Form1.databasebtn.Enabled = True
                Form1.purchasesbtn.Enabled = True
                Form1.signoutbtn.Enabled = True

                ProgressBar1.Value = 0


            End If
        Catch ex As Exception
            MsgBox("plz inset the valid data")
        End Try

        connection.Close()
    End Sub

    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ProgressBar1.Hide()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ProgressBar1.Show()
        ProgressBar1.Value = ProgressBar1.Value + 25
        If ProgressBar1.Value = 100 Then
            Timer1.Enabled = False

        End If


    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If passtxt.UseSystemPasswordChar = True Then
            passtxt.UseSystemPasswordChar = False
        Else
            passtxt.UseSystemPasswordChar = True

        End If
    End Sub
End Class