﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Sales
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.sidtxt = New System.Windows.Forms.TextBox()
        Me.onofflbl = New System.Windows.Forms.Label()
        Me.sid = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.scredittxt = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.sgivenamttxt = New System.Windows.Forms.TextBox()
        Me.spricetxt = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.sgivenbytxt = New System.Windows.Forms.TextBox()
        Me.sproducttxt = New System.Windows.Forms.TextBox()
        Me.scontactnotxt = New System.Windows.Forms.TextBox()
        Me.saddresstxt = New System.Windows.Forms.TextBox()
        Me.scustomernametxt = New System.Windows.Forms.TextBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Panel1.Controls.Add(Me.GroupBox2)
        Me.Panel1.Controls.Add(Me.GroupBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(984, 467)
        Me.Panel1.TabIndex = 1
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.GroupBox2.Controls.Add(Me.sidtxt)
        Me.GroupBox2.Controls.Add(Me.onofflbl)
        Me.GroupBox2.Controls.Add(Me.sid)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Location = New System.Drawing.Point(41, 33)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(902, 61)
        Me.GroupBox2.TabIndex = 51
        Me.GroupBox2.TabStop = False
        '
        'sidtxt
        '
        Me.sidtxt.BackColor = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.sidtxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.sidtxt.ForeColor = System.Drawing.Color.White
        Me.sidtxt.Location = New System.Drawing.Point(663, 22)
        Me.sidtxt.Multiline = True
        Me.sidtxt.Name = "sidtxt"
        Me.sidtxt.Size = New System.Drawing.Size(104, 23)
        Me.sidtxt.TabIndex = 52
        '
        'onofflbl
        '
        Me.onofflbl.AutoSize = True
        Me.onofflbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.onofflbl.ForeColor = System.Drawing.Color.White
        Me.onofflbl.Location = New System.Drawing.Point(815, 23)
        Me.onofflbl.Name = "onofflbl"
        Me.onofflbl.Size = New System.Drawing.Size(19, 20)
        Me.onofflbl.TabIndex = 48
        Me.onofflbl.Text = "--"
        '
        'sid
        '
        Me.sid.AutoSize = True
        Me.sid.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.sid.ForeColor = System.Drawing.Color.White
        Me.sid.Location = New System.Drawing.Point(85, 23)
        Me.sid.Name = "sid"
        Me.sid.Size = New System.Drawing.Size(54, 20)
        Me.sid.TabIndex = 47
        Me.sid.Text = "00000"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(27, 23)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(45, 20)
        Me.Label8.TabIndex = 46
        Me.Label8.Text = "SID :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, CType(((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Cyan
        Me.Label1.Location = New System.Drawing.Point(307, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(219, 37)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "Sales Record"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.DateTimePicker1)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Location = New System.Drawing.Point(41, 121)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(903, 303)
        Me.GroupBox1.TabIndex = 50
        Me.GroupBox1.TabStop = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Cyan
        Me.Button3.Location = New System.Drawing.Point(412, 226)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(114, 32)
        Me.Button3.TabIndex = 50
        Me.Button3.Text = "Get Data"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(611, 181)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(61, 13)
        Me.Label12.TabIndex = 49
        Me.Label12.Text = "mm-dd-yyyy"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(536, 189)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(52, 20)
        Me.Label7.TabIndex = 44
        Me.Label7.Text = "Date :"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.CustomFormat = ""
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimePicker1.Location = New System.Drawing.Point(610, 194)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(217, 20)
        Me.DateTimePicker1.TabIndex = 48
        Me.DateTimePicker1.Value = New Date(2021, 11, 14, 0, 0, 0, 0)
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(71, 86)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(76, 20)
        Me.Label3.TabIndex = 28
        Me.Label3.Text = "Address :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(15, 36)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(132, 20)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = "Customer Name :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(43, 131)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(104, 20)
        Me.Label4.TabIndex = 30
        Me.Label4.Text = "Contact NO. :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(75, 180)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(72, 20)
        Me.Label5.TabIndex = 32
        Me.Label5.Text = "Product :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(61, 233)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(86, 20)
        Me.Label6.TabIndex = 34
        Me.Label6.Text = "GIven BY :"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Cyan
        Me.Button1.Location = New System.Drawing.Point(559, 226)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(114, 32)
        Me.Button1.TabIndex = 26
        Me.Button1.Text = "Update"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Cyan
        Me.Button2.Location = New System.Drawing.Point(713, 226)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(114, 32)
        Me.Button2.TabIndex = 27
        Me.Button2.Text = "Save"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(490, 85)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(91, 20)
        Me.Label10.TabIndex = 38
        Me.Label10.Text = "Given Amt :"
        '
        'scredittxt
        '
        Me.scredittxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.scredittxt.Location = New System.Drawing.Point(651, 254)
        Me.scredittxt.Multiline = True
        Me.scredittxt.Name = "scredittxt"
        Me.scredittxt.Size = New System.Drawing.Size(217, 30)
        Me.scredittxt.TabIndex = 41
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(570, 254)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(59, 20)
        Me.Label9.TabIndex = 40
        Me.Label9.Text = "Credit :"
        '
        'sgivenamttxt
        '
        Me.sgivenamttxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.sgivenamttxt.Location = New System.Drawing.Point(651, 206)
        Me.sgivenamttxt.Multiline = True
        Me.sgivenamttxt.Name = "sgivenamttxt"
        Me.sgivenamttxt.Size = New System.Drawing.Size(217, 30)
        Me.sgivenamttxt.TabIndex = 39
        '
        'spricetxt
        '
        Me.spricetxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.spricetxt.Location = New System.Drawing.Point(651, 154)
        Me.spricetxt.Multiline = True
        Me.spricetxt.Name = "spricetxt"
        Me.spricetxt.Size = New System.Drawing.Size(217, 30)
        Me.spricetxt.TabIndex = 37
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(570, 154)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(52, 20)
        Me.Label11.TabIndex = 36
        Me.Label11.Text = "Price :"
        '
        'sgivenbytxt
        '
        Me.sgivenbytxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.sgivenbytxt.Location = New System.Drawing.Point(197, 349)
        Me.sgivenbytxt.Multiline = True
        Me.sgivenbytxt.Name = "sgivenbytxt"
        Me.sgivenbytxt.Size = New System.Drawing.Size(217, 30)
        Me.sgivenbytxt.TabIndex = 35
        '
        'sproducttxt
        '
        Me.sproducttxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.sproducttxt.Location = New System.Drawing.Point(197, 299)
        Me.sproducttxt.Multiline = True
        Me.sproducttxt.Name = "sproducttxt"
        Me.sproducttxt.Size = New System.Drawing.Size(217, 30)
        Me.sproducttxt.TabIndex = 33
        '
        'scontactnotxt
        '
        Me.scontactnotxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.scontactnotxt.Location = New System.Drawing.Point(197, 252)
        Me.scontactnotxt.Multiline = True
        Me.scontactnotxt.Name = "scontactnotxt"
        Me.scontactnotxt.Size = New System.Drawing.Size(217, 30)
        Me.scontactnotxt.TabIndex = 31
        '
        'saddresstxt
        '
        Me.saddresstxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.saddresstxt.Location = New System.Drawing.Point(197, 204)
        Me.saddresstxt.Multiline = True
        Me.saddresstxt.Name = "saddresstxt"
        Me.saddresstxt.Size = New System.Drawing.Size(217, 30)
        Me.saddresstxt.TabIndex = 29
        '
        'scustomernametxt
        '
        Me.scustomernametxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.scustomernametxt.Location = New System.Drawing.Point(197, 152)
        Me.scustomernametxt.Multiline = True
        Me.scustomernametxt.Name = "scustomernametxt"
        Me.scustomernametxt.Size = New System.Drawing.Size(217, 30)
        Me.scustomernametxt.TabIndex = 25
        '
        'Sales
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(984, 467)
        Me.Controls.Add(Me.scredittxt)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.sgivenamttxt)
        Me.Controls.Add(Me.spricetxt)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.sgivenbytxt)
        Me.Controls.Add(Me.sproducttxt)
        Me.Controls.Add(Me.scontactnotxt)
        Me.Controls.Add(Me.saddresstxt)
        Me.Controls.Add(Me.scustomernametxt)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Sales"
        Me.Text = "Sales"
        Me.Panel1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label7 As Label
    Friend WithEvents scredittxt As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents sgivenamttxt As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents spricetxt As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents sgivenbytxt As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents sproducttxt As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents scontactnotxt As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents saddresstxt As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents scustomernametxt As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents sid As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents onofflbl As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents sidtxt As TextBox
    Friend WithEvents Button3 As Button
End Class
