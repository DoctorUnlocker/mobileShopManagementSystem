﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class purchasesdatabase
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.pdatabasetxt = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.MobileappDataSet3 = New MOBILEAPP.mobileappDataSet3()
        Me.PurchasestableBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Purchases_tableTableAdapter = New MOBILEAPP.mobileappDataSet3TableAdapters.purchases_tableTableAdapter()
        Me.PIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ShopDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GivenByDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TakenByDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.QuantityDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PriceDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GivenAmtDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CreditDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MobileappDataSet3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PurchasestableBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Panel1.Controls.Add(Me.DataGridView1)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(984, 412)
        Me.Panel1.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(55, Byte), Integer), CType(CType(55, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Panel2.Controls.Add(Me.Button2)
        Me.Panel2.Controls.Add(Me.Button1)
        Me.Panel2.Controls.Add(Me.pdatabasetxt)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(984, 51)
        Me.Panel2.TabIndex = 1
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Yellow
        Me.Button2.Location = New System.Drawing.Point(393, 12)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(130, 28)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "Delete"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Yellow
        Me.Button1.Location = New System.Drawing.Point(235, 12)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(130, 28)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Search"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'pdatabasetxt
        '
        Me.pdatabasetxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.pdatabasetxt.Location = New System.Drawing.Point(12, 12)
        Me.pdatabasetxt.Multiline = True
        Me.pdatabasetxt.Name = "pdatabasetxt"
        Me.pdatabasetxt.Size = New System.Drawing.Size(192, 28)
        Me.pdatabasetxt.TabIndex = 0
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.Olive
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.PIDDataGridViewTextBoxColumn, Me.ShopDataGridViewTextBoxColumn, Me.GivenByDataGridViewTextBoxColumn, Me.TakenByDataGridViewTextBoxColumn, Me.ProductDataGridViewTextBoxColumn, Me.QuantityDataGridViewTextBoxColumn, Me.PriceDataGridViewTextBoxColumn, Me.GivenAmtDataGridViewTextBoxColumn, Me.CreditDataGridViewTextBoxColumn, Me.DateDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.PurchasestableBindingSource
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView1.Location = New System.Drawing.Point(0, 51)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(984, 361)
        Me.DataGridView1.TabIndex = 2
        '
        'MobileappDataSet3
        '
        Me.MobileappDataSet3.DataSetName = "mobileappDataSet3"
        Me.MobileappDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'PurchasestableBindingSource
        '
        Me.PurchasestableBindingSource.DataMember = "purchases_table"
        Me.PurchasestableBindingSource.DataSource = Me.MobileappDataSet3
        '
        'Purchases_tableTableAdapter
        '
        Me.Purchases_tableTableAdapter.ClearBeforeFill = True
        '
        'PIDDataGridViewTextBoxColumn
        '
        Me.PIDDataGridViewTextBoxColumn.DataPropertyName = "PID"
        Me.PIDDataGridViewTextBoxColumn.HeaderText = "PID"
        Me.PIDDataGridViewTextBoxColumn.Name = "PIDDataGridViewTextBoxColumn"
        '
        'ShopDataGridViewTextBoxColumn
        '
        Me.ShopDataGridViewTextBoxColumn.DataPropertyName = "Shop"
        Me.ShopDataGridViewTextBoxColumn.HeaderText = "Shop"
        Me.ShopDataGridViewTextBoxColumn.Name = "ShopDataGridViewTextBoxColumn"
        '
        'GivenByDataGridViewTextBoxColumn
        '
        Me.GivenByDataGridViewTextBoxColumn.DataPropertyName = "Given_By"
        Me.GivenByDataGridViewTextBoxColumn.HeaderText = "Given_By"
        Me.GivenByDataGridViewTextBoxColumn.Name = "GivenByDataGridViewTextBoxColumn"
        '
        'TakenByDataGridViewTextBoxColumn
        '
        Me.TakenByDataGridViewTextBoxColumn.DataPropertyName = "Taken_By"
        Me.TakenByDataGridViewTextBoxColumn.HeaderText = "Taken_By"
        Me.TakenByDataGridViewTextBoxColumn.Name = "TakenByDataGridViewTextBoxColumn"
        '
        'ProductDataGridViewTextBoxColumn
        '
        Me.ProductDataGridViewTextBoxColumn.DataPropertyName = "Product"
        Me.ProductDataGridViewTextBoxColumn.HeaderText = "Product"
        Me.ProductDataGridViewTextBoxColumn.Name = "ProductDataGridViewTextBoxColumn"
        '
        'QuantityDataGridViewTextBoxColumn
        '
        Me.QuantityDataGridViewTextBoxColumn.DataPropertyName = "Quantity"
        Me.QuantityDataGridViewTextBoxColumn.HeaderText = "Quantity"
        Me.QuantityDataGridViewTextBoxColumn.Name = "QuantityDataGridViewTextBoxColumn"
        '
        'PriceDataGridViewTextBoxColumn
        '
        Me.PriceDataGridViewTextBoxColumn.DataPropertyName = "Price"
        Me.PriceDataGridViewTextBoxColumn.HeaderText = "Price"
        Me.PriceDataGridViewTextBoxColumn.Name = "PriceDataGridViewTextBoxColumn"
        '
        'GivenAmtDataGridViewTextBoxColumn
        '
        Me.GivenAmtDataGridViewTextBoxColumn.DataPropertyName = "Given_Amt"
        Me.GivenAmtDataGridViewTextBoxColumn.HeaderText = "Given_Amt"
        Me.GivenAmtDataGridViewTextBoxColumn.Name = "GivenAmtDataGridViewTextBoxColumn"
        '
        'CreditDataGridViewTextBoxColumn
        '
        Me.CreditDataGridViewTextBoxColumn.DataPropertyName = "Credit"
        Me.CreditDataGridViewTextBoxColumn.HeaderText = "Credit"
        Me.CreditDataGridViewTextBoxColumn.Name = "CreditDataGridViewTextBoxColumn"
        '
        'DateDataGridViewTextBoxColumn
        '
        Me.DateDataGridViewTextBoxColumn.DataPropertyName = "Date"
        Me.DateDataGridViewTextBoxColumn.HeaderText = "Date"
        Me.DateDataGridViewTextBoxColumn.Name = "DateDataGridViewTextBoxColumn"
        '
        'purchasesdatabase
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(984, 412)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "purchasesdatabase"
        Me.Text = "purchasesdatabase"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MobileappDataSet3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PurchasestableBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents pdatabasetxt As TextBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents MobileappDataSet3 As mobileappDataSet3
    Friend WithEvents PurchasestableBindingSource As BindingSource
    Friend WithEvents Purchases_tableTableAdapter As mobileappDataSet3TableAdapters.purchases_tableTableAdapter
    Friend WithEvents PIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ShopDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents GivenByDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TakenByDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ProductDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents QuantityDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PriceDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents GivenAmtDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CreditDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DateDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
