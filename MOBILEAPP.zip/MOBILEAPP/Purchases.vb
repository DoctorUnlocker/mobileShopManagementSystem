﻿Imports System.Data.SqlClient
Imports System.Data
Public Class Purchases
    Dim con As New SqlConnection("Server= rip; Database = mobileapp; Integrated Security = true")
    Dim cmd As New SqlCommand
    Dim dt As DataTable
    Dim da As New SqlDataAdapter()
    Dim random As New Random()
    Private Sub Purchases_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        If con.State = ConnectionState.Open Then
            onofflbl.Text = "ON"
        Else
            onofflbl.Text = "off"
        End If
        pid.Text = random.Next(100000)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        If con.State = ConnectionState.Open Then
            onofflbl.Text = "ON"
        Else
            onofflbl.Text = "off"
        End If
        Try
            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "INSERT INTO [dbo].[purchases_table]
           ([PID]
           ,[Shop]
           ,[Given_By]
           ,[Taken_By] 
           ,[Product]
           ,[Quantity]
           ,[Price]
           ,[Given_Amt]
           ,[Credit]
           ,[Date])
        VALUES('" + pid.Text + "','" + pshoptxt.Text + "','" + pgivenbytxt.Text + "','" + ptakenbytxt.Text + "','" + pproducttxt.Text + "','" + pquantitytxt.Text + "','" + ppricetxt.Text + "','" + pgivenamttxt.Text + "','" + pcredittxt.Text + "','" + DateTimePicker1.Text + "')"
            cmd.ExecuteNonQuery()

            MessageBox.Show("Record Inserted Successfully")
        Catch ex As Exception
            MsgBox("plz enter the valid data")
        End Try
        con.Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        If con.State = ConnectionState.Open Then
            onofflbl.Text = "ON"
        Else
            onofflbl.Text = "off"
        End If
        If pidtxt.Text = Nothing Then
            MsgBox("PID CANNOT BE EMPTY")
        Else
            Try

                cmd = con.CreateCommand()
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "select * from [dbo].[purchases_table] where [PID]='" + pidtxt.Text + "'"
                cmd.ExecuteNonQuery()
                Dim sda As New SqlDataAdapter(cmd)
                Dim dt As New DataTable()
                sda.Fill(dt)
                If dt.Rows.Count > 0 Then
                    pidtxt.Text = dt.Rows(0)(0).ToString()
                    pshoptxt.Text = dt.Rows(0)(1).ToString()
                    pgivenbytxt.Text = dt.Rows(0)(2).ToString()
                    ptakenbytxt.Text = dt.Rows(0)(3).ToString()
                    pproducttxt.Text = dt.Rows(0)(4).ToString()
                    pquantitytxt.Text = dt.Rows(0)(5).ToString()
                    ppricetxt.Text = dt.Rows(0)(6).ToString()
                    pgivenamttxt.Text = dt.Rows(0)(7).ToString()
                    pcredittxt.Text = dt.Rows(0)(8).ToString()
                    DateTimePicker1.Text = dt.Rows(0)(9).ToString()
                Else
                    MsgBox("please enter the valid PID")
                End If

            Catch ex As Exception
                MsgBox("plz enter the valid PID")
            End Try
        End If


        con.Close()


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        If con.State = ConnectionState.Open Then
            onofflbl.Text = "ON"
        Else
            onofflbl.Text = "off"
        End If
        If pidtxt.Text = Nothing Then
            MsgBox("PID CANNOT BE EMPTY")
        Else
            Try

                cmd = con.CreateCommand()
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "Update [dbo].[purchases_table]
   SET [PID] ='" + pidtxt.Text + "'
      ,[Shop] ='" + pshoptxt.Text + "'
      ,[Given_By] ='" + pgivenbytxt.Text + "'
      ,[Taken_By] = '" + ptakenbytxt.Text + "'
      ,[Product] = '" + pproducttxt.Text + "'
      ,[Quantity] = '" + pquantitytxt.Text + "'
      ,[Price] ='" + ppricetxt.Text + "'
      ,[Given_Amt] = '" + pgivenamttxt.Text + "'
      ,[Credit] ='" + pcredittxt.Text + "'
      ,[Date] ='" + DateTimePicker1.Text + "'
 WHERE [PID] ='" + pidtxt.Text + "' "
                cmd.ExecuteNonQuery()

                MessageBox.Show("Record Updated Successfully")
            Catch ex As Exception
                MsgBox("plz enter the valid data")
            End Try
        End If
        con.Close()
    End Sub


End Class