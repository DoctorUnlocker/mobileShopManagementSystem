﻿Imports System.Data.SqlClient
Imports System.Data
Public Class salesdatabase
    Dim con As New SqlConnection("Server= rip; Database = mobileapp; Integrated Security = true")
    Dim cmd As New SqlCommand
    Private Sub salesdatabase_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        disp_data("")
    End Sub
    Public Sub disp_data(ds As String)
        Dim cmd As New SqlCommand("select *  from sales_table where concat(SID,Customer_Name,Address,Contact_No,Product,Given_By,Price,Given_Amt,Credit,Date) like '%" & ds & "%' ", con)
        Dim da As New SqlDataAdapter(cmd)
        Dim dt As New DataTable()
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        disp_data(sdatabasetxt.Text)
        con.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        Try
            If sdatabasetxt.Text = "" Then
                MsgBox("SID error, please input valid SID")
            Else
                cmd = con.CreateCommand()
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "DELETE From [dbo].[sales_table]
      Where [SID] ='" + sdatabasetxt.Text + "' "
                cmd.ExecuteNonQuery()

                MessageBox.Show("a record is deleted")
            End If

        Catch ex As Exception
            MsgBox("SID error, please input valid SID")
        End Try
        disp_data("")
        con.Close()
    End Sub
End Class