﻿Imports System.Data.SqlClient
Imports System.Data
Public Class purchasesdatabase
    Dim con As New SqlConnection("Server= rip; Database = mobileapp; Integrated Security = true")
    Dim cmd As New SqlCommand
    Private Sub purchasesdatabase_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        disp_data("")
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        disp_data(pdatabasetxt.Text)
        con.Close()
    End Sub
    Public Sub disp_data(ds As String)
        Dim cmd As New SqlCommand("select *  from purchases_table where concat(PID,Shop,Given_By,Taken_By,Product,Quantity,Price,Given_Amt,Credit,Date) like '%" & ds & "%' ", con)
        Dim da As New SqlDataAdapter(cmd)
        Dim dt As New DataTable()
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        Try
            If pdatabasetxt.Text = "" Then
                MsgBox("PID error, please input valid PID")
            Else
                cmd = con.CreateCommand()
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "DELETE From [dbo].[purchases_table]
      Where [PID] ='" + pdatabasetxt.Text + "' "
                cmd.ExecuteNonQuery()


                MessageBox.Show("a record is deleted")
            End If

        Catch ex As Exception
            MsgBox("PID error, please input valid PID")
        End Try
        disp_data("")
        con.Close()
    End Sub
End Class