﻿Public Class Database
    Dim cf As Form

    Private Sub IconButton1_Click(sender As Object, e As EventArgs) Handles IconButton1.Click
        OpenChildForm(New salesdatabase)
    End Sub
    Public Sub OpenChildForm(childForm As Form)
        If cf IsNot Nothing Then
            cf.Close()

        End If
        cf = childForm
        childForm.TopLevel = False
        childForm.FormBorderStyle = FormBorderStyle.None
        childForm.Dock = DockStyle.Fill
        Panel3.Controls.Add(childForm)
        Panel3.Tag = childForm
        childForm.BringToFront()
        childForm.Show()
    End Sub

    Private Sub IconButton2_Click(sender As Object, e As EventArgs) Handles IconButton2.Click
        OpenChildForm(New purchasesdatabase)
    End Sub

    Private Sub IconButton3_Click(sender As Object, e As EventArgs) Handles IconButton3.Click
        OpenChildForm(New expensesdatabase)
    End Sub

    Private Sub Database_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub IconButton4_Click(sender As Object, e As EventArgs) Handles IconButton4.Click
        OpenChildForm(New admindatabase)
    End Sub
End Class