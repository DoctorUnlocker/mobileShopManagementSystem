﻿Imports System.Data.SqlClient
Imports System.Data
Public Class Expenses
    Dim con As New SqlConnection("Server= rip; Database = mobileapp; Integrated Security = true")
    Dim cmd As New SqlCommand
    Dim random As New Random()
    Private Sub Expenses_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        If con.State = ConnectionState.Open Then
            onofflbl.Text = "ON"
        Else
            onofflbl.Text = "off"
        End If
        eid.Text = random.Next(100000)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        If con.State = ConnectionState.Open Then
            onofflbl.Text = "ON"
        Else
            onofflbl.Text = "off"
        End If
        Try
            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = " INSERT INTO [dbo].[expenses_table]
           ([EID]
           ,[Shop]
           ,[Address]
           ,[Product]
           ,[Order_By]
           ,[Quantity]
           ,[Price]
           ,[Given_Amt]
           ,[Credit]
           ,[Date])
     VALUES('" + eid.Text + "','" + eshoptxt.Text + "','" + eaddresstxt.Text + "','" + eproducttxt.Text + "','" + eorderbytxt.Text + "','" + equantitytxt.Text + "','" + epricetxt.Text + "','" + egivenamttxt.Text + "','" + ecredittxt.Text + "','" + DateTimePicker1.Text + "')"
            cmd.ExecuteNonQuery()

            MessageBox.Show("Record saved Successfully")
        Catch ex As Exception
            MsgBox("input data error,plz input the valid data")
        End Try
        con.Close()
    End Sub

    Private Sub Button3_Click_1(sender As Object, e As EventArgs) Handles Button3.Click
        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        If con.State = ConnectionState.Open Then
            onofflbl.Text = "ON"
        Else
            onofflbl.Text = "off"
        End If
        If eidtxt.Text = Nothing Then
            MsgBox("EID CANNOT BE EMPTY")
        Else

            Try
                cmd = con.CreateCommand()
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "select * from [dbo].[expenses_table] where [EID]='" + eidtxt.Text + "'"
                cmd.ExecuteNonQuery()
                Dim sda As New SqlDataAdapter(cmd)
                Dim dt As New DataTable()
                sda.Fill(dt)
                If dt.Rows.Count > 0 Then
                    eidtxt.Text = dt.Rows(0)(0).ToString()
                    eshoptxt.Text = dt.Rows(0)(1).ToString()
                    eaddresstxt.Text = dt.Rows(0)(2).ToString()
                    eproducttxt.Text = dt.Rows(0)(3).ToString()
                    eorderbytxt.Text = dt.Rows(0)(4).ToString()
                    equantitytxt.Text = dt.Rows(0)(5).ToString()
                    epricetxt.Text = dt.Rows(0)(6).ToString()
                    egivenamttxt.Text = dt.Rows(0)(7).ToString()
                    ecredittxt.Text = dt.Rows(0)(8).ToString()
                    DateTimePicker1.Text = dt.Rows(0)(9).ToString()
                Else
                    MsgBox("plz enter the correct SID")
                End If
            Catch ex As Exception
                MsgBox("plz enter the correct SID")
            End Try
        End If
        con.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        If con.State = ConnectionState.Open Then
            onofflbl.Text = "ON"
        Else
            onofflbl.Text = "off"
        End If
        If eidtxt.Text = Nothing Then
            MsgBox("EID CANNOT BE EMPTY")
        Else
            Try
                cmd = con.CreateCommand()
                cmd.CommandType = CommandType.Text
                cmd.CommandText = " Update [dbo].[expenses_table]
   SET [EID] ='" + eidtxt.Text + "'
      ,[Shop] = '" + eshoptxt.Text + "'
      ,[Address] = '" + eaddresstxt.Text + "'
      ,[Product] = '" + eproducttxt.Text + "'
      ,[Order_By] = '" + eorderbytxt.Text + "'
      ,[Quantity] ='" + equantitytxt.Text + "'
      ,[Price] ='" + epricetxt.Text + "'
      ,[Given_Amt] = '" + egivenamttxt.Text + "'
      ,[Credit] = '" + ecredittxt.Text + "'
      ,[Date] ='" + DateTimePicker1.Text + "'
 WHERE  [EID] ='" + eidtxt.Text + "' "
                cmd.ExecuteNonQuery()

                MessageBox.Show("Record Updated Successfully")
            Catch ex As Exception
                MsgBox("input data error, plz input the valid data")
            End Try
        End If

        con.Close()
    End Sub
End Class