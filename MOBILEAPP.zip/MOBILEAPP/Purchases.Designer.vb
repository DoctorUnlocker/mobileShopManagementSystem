﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Purchases
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.pidtxt = New System.Windows.Forms.TextBox()
        Me.onofflbl = New System.Windows.Forms.Label()
        Me.pid = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.pcredittxt = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.pgivenamttxt = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.ppricetxt = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.pquantitytxt = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.pproducttxt = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ptakenbytxt = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.pgivenbytxt = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.pshoptxt = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Panel1.Controls.Add(Me.GroupBox2)
        Me.Panel1.Controls.Add(Me.GroupBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(984, 467)
        Me.Panel1.TabIndex = 1
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.GroupBox2.Controls.Add(Me.pidtxt)
        Me.GroupBox2.Controls.Add(Me.onofflbl)
        Me.GroupBox2.Controls.Add(Me.pid)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Location = New System.Drawing.Point(51, 25)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(883, 72)
        Me.GroupBox2.TabIndex = 52
        Me.GroupBox2.TabStop = False
        '
        'pidtxt
        '
        Me.pidtxt.BackColor = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.pidtxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.pidtxt.ForeColor = System.Drawing.Color.White
        Me.pidtxt.Location = New System.Drawing.Point(675, 28)
        Me.pidtxt.Multiline = True
        Me.pidtxt.Name = "pidtxt"
        Me.pidtxt.Size = New System.Drawing.Size(104, 23)
        Me.pidtxt.TabIndex = 53
        '
        'onofflbl
        '
        Me.onofflbl.AutoSize = True
        Me.onofflbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.onofflbl.ForeColor = System.Drawing.Color.White
        Me.onofflbl.Location = New System.Drawing.Point(824, 27)
        Me.onofflbl.Name = "onofflbl"
        Me.onofflbl.Size = New System.Drawing.Size(19, 20)
        Me.onofflbl.TabIndex = 46
        Me.onofflbl.Text = "--"
        '
        'pid
        '
        Me.pid.AutoSize = True
        Me.pid.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.pid.ForeColor = System.Drawing.Color.White
        Me.pid.Location = New System.Drawing.Point(81, 29)
        Me.pid.Name = "pid"
        Me.pid.Size = New System.Drawing.Size(54, 20)
        Me.pid.TabIndex = 45
        Me.pid.Text = "00000"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(31, 29)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(44, 20)
        Me.Label8.TabIndex = 42
        Me.Label8.Text = "PID :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, CType(((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Fuchsia
        Me.Label1.Location = New System.Drawing.Point(314, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(295, 37)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "Purchases Record"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.DateTimePicker1)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.pcredittxt)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.pgivenamttxt)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.ppricetxt)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.pquantitytxt)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.pproducttxt)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.ptakenbytxt)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.pgivenbytxt)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.pshoptxt)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(52, 118)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(883, 314)
        Me.GroupBox1.TabIndex = 51
        Me.GroupBox1.TabStop = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Fuchsia
        Me.Button3.Location = New System.Drawing.Point(405, 238)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(114, 32)
        Me.Button3.TabIndex = 51
        Me.Button3.Text = "Get Data"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(600, 183)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(61, 13)
        Me.Label12.TabIndex = 50
        Me.Label12.Text = "mm-dd-yyyy"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.CustomFormat = ""
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimePicker1.Location = New System.Drawing.Point(600, 198)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(217, 20)
        Me.DateTimePicker1.TabIndex = 47
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(519, 199)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(52, 20)
        Me.Label7.TabIndex = 44
        Me.Label7.Text = "Date :"
        '
        'pcredittxt
        '
        Me.pcredittxt.Location = New System.Drawing.Point(600, 143)
        Me.pcredittxt.Multiline = True
        Me.pcredittxt.Name = "pcredittxt"
        Me.pcredittxt.Size = New System.Drawing.Size(217, 30)
        Me.pcredittxt.TabIndex = 41
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(512, 143)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(59, 20)
        Me.Label9.TabIndex = 40
        Me.Label9.Text = "Credit :"
        '
        'pgivenamttxt
        '
        Me.pgivenamttxt.Location = New System.Drawing.Point(600, 95)
        Me.pgivenamttxt.Multiline = True
        Me.pgivenamttxt.Name = "pgivenamttxt"
        Me.pgivenamttxt.Size = New System.Drawing.Size(217, 30)
        Me.pgivenamttxt.TabIndex = 39
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(478, 95)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(93, 20)
        Me.Label10.TabIndex = 38
        Me.Label10.Text = "GIven Amt :"
        '
        'ppricetxt
        '
        Me.ppricetxt.Location = New System.Drawing.Point(600, 43)
        Me.ppricetxt.Multiline = True
        Me.ppricetxt.Name = "ppricetxt"
        Me.ppricetxt.Size = New System.Drawing.Size(217, 30)
        Me.ppricetxt.TabIndex = 37
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(519, 43)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(52, 20)
        Me.Label11.TabIndex = 36
        Me.Label11.Text = "Price :"
        '
        'pquantitytxt
        '
        Me.pquantitytxt.Location = New System.Drawing.Point(146, 238)
        Me.pquantitytxt.Multiline = True
        Me.pquantitytxt.Name = "pquantitytxt"
        Me.pquantitytxt.Size = New System.Drawing.Size(217, 30)
        Me.pquantitytxt.TabIndex = 35
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(65, 238)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(76, 20)
        Me.Label6.TabIndex = 34
        Me.Label6.Text = "Quantity :"
        '
        'pproducttxt
        '
        Me.pproducttxt.Location = New System.Drawing.Point(146, 188)
        Me.pproducttxt.Multiline = True
        Me.pproducttxt.Name = "pproducttxt"
        Me.pproducttxt.Size = New System.Drawing.Size(217, 30)
        Me.pproducttxt.TabIndex = 33
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(50, 141)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(87, 20)
        Me.Label5.TabIndex = 32
        Me.Label5.Text = "Taken BY :"
        '
        'ptakenbytxt
        '
        Me.ptakenbytxt.Location = New System.Drawing.Point(146, 141)
        Me.ptakenbytxt.Multiline = True
        Me.ptakenbytxt.Name = "ptakenbytxt"
        Me.ptakenbytxt.Size = New System.Drawing.Size(217, 30)
        Me.ptakenbytxt.TabIndex = 31
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(65, 190)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(72, 20)
        Me.Label4.TabIndex = 30
        Me.Label4.Text = "Product :"
        '
        'pgivenbytxt
        '
        Me.pgivenbytxt.Location = New System.Drawing.Point(146, 93)
        Me.pgivenbytxt.Multiline = True
        Me.pgivenbytxt.Name = "pgivenbytxt"
        Me.pgivenbytxt.Size = New System.Drawing.Size(217, 30)
        Me.pgivenbytxt.TabIndex = 29
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(50, 95)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(84, 20)
        Me.Label3.TabIndex = 28
        Me.Label3.Text = "Given BY :"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Fuchsia
        Me.Button2.Location = New System.Drawing.Point(703, 238)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(114, 32)
        Me.Button2.TabIndex = 27
        Me.Button2.Text = "Save"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Fuchsia
        Me.Button1.Location = New System.Drawing.Point(550, 238)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(114, 32)
        Me.Button1.TabIndex = 26
        Me.Button1.Text = "Update"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'pshoptxt
        '
        Me.pshoptxt.Location = New System.Drawing.Point(146, 41)
        Me.pshoptxt.Multiline = True
        Me.pshoptxt.Name = "pshoptxt"
        Me.pshoptxt.Size = New System.Drawing.Size(217, 30)
        Me.pshoptxt.TabIndex = 25
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(79, 41)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 20)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = "Shop :"
        '
        'Purchases
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(984, 467)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Purchases"
        Me.Text = "Purchases"
        Me.Panel1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents pcredittxt As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents pgivenamttxt As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents ppricetxt As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents pquantitytxt As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents pproducttxt As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents ptakenbytxt As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents pgivenbytxt As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents pshoptxt As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents pid As Label
    Friend WithEvents onofflbl As Label
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents Label12 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents pidtxt As TextBox
    Friend WithEvents Button3 As Button
End Class
