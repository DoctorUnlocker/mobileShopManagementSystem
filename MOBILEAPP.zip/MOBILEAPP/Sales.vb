﻿Imports System.Data.SqlClient
Imports System.Data
Public Class Sales
    Dim con As New SqlConnection("Server= rip; Database = mobileapp; Integrated Security = true")
    Dim cmd As New SqlCommand

    Dim random As New Random()


    Private Sub Sales_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        If con.State = ConnectionState.Open Then
            onofflbl.Text = "ON"
        Else
            onofflbl.Text = "off"
        End If
        sid.Text = random.Next(100000)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        If con.State = ConnectionState.Open Then
            onofflbl.Text = "ON"
        Else
            onofflbl.Text = "off"
        End If
        Try
            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "INSERT INTO [dbo].[sales_table]
           ([SID]
           ,[Customer_Name]
           ,[Address]
           ,[Contact_No]
           ,[Product]
           ,[Given_By]
           ,[Price]
           ,[Given_Amt]
           ,[Credit]
           ,[Date])
     VALUES('" + sid.Text + "','" + scustomernametxt.Text + "','" + saddresstxt.Text + "','" + scontactnotxt.Text + "','" + sproducttxt.Text + "','" + sgivenbytxt.Text + "','" + spricetxt.Text + "','" + sgivenamttxt.Text + "','" + scredittxt.Text + "','" + DateTimePicker1.Text + "')"
            cmd.ExecuteNonQuery()
            MessageBox.Show("Record is saved now")
        Catch ex As Exception
            MsgBox("plz provide the valid data,data cannot be saved")
        End Try
        con.Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
           If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        If con.State = ConnectionState.Open Then
            onofflbl.Text = "ON"
        Else
            onofflbl.Text = "off"
        End If
        If sidtxt.Text = Nothing Then
            MsgBox("SID CANNOT BE EMPTY")
        Else

            Try
                cmd = con.CreateCommand()
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "select * from [dbo].[sales_table] where [SID]='" + sidtxt.Text + "'"
                cmd.ExecuteNonQuery()
                Dim sda As New SqlDataAdapter(cmd)
                Dim dt As New DataTable()
                sda.Fill(dt)
                If dt.Rows.Count > 0 Then
                    sidtxt.Text = dt.Rows(0)(0).ToString()
                    scustomernametxt.Text = dt.Rows(0)(1).ToString()
                    saddresstxt.Text = dt.Rows(0)(2).ToString()
                    scontactnotxt.Text = dt.Rows(0)(3).ToString()
                    sproducttxt.Text = dt.Rows(0)(4).ToString()
                    sgivenbytxt.Text = dt.Rows(0)(5).ToString()
                    spricetxt.Text = dt.Rows(0)(6).ToString()
                    sgivenamttxt.Text = dt.Rows(0)(7).ToString()
                    scredittxt.Text = dt.Rows(0)(8).ToString()
                    DateTimePicker1.Text = dt.Rows(0)(9).ToString()
                Else
                    MsgBox("plz enter valid SID")
                End If
            Catch ex As Exception
                MsgBox("plz enter valid SID")
            End Try
        End If




        con.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        If con.State = ConnectionState.Open Then
            onofflbl.Text = "ON"
        Else
            onofflbl.Text = "off"
        End If
        If sidtxt.Text = Nothing Then
            MsgBox("SID CANNOT BE EMPTY")
        Else
            Try
                cmd = con.CreateCommand()
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "Update [dbo].[sales_table]
   SET [SID] ='" + sidtxt.Text + "'
      ,[Customer_Name] = '" + scustomernametxt.Text + "'
      ,[Address] = '" + saddresstxt.Text + "'
      ,[Contact_No] = '" + scontactnotxt.Text + "'
      ,[Product] = '" + sproducttxt.Text + "'
      ,[Given_By] ='" + sgivenbytxt.Text + "'
      ,[Price] = '" + spricetxt.Text + "'
      ,[Given_Amt] ='" + sgivenamttxt.Text + "'
      ,[Credit] ='" + scredittxt.Text + "'
      ,[Date] = '" + DateTimePicker1.Text + "'
 WHERE [SID] ='" + sidtxt.Text + "' "
                cmd.ExecuteNonQuery()

                MessageBox.Show("Record is updated now")

            Catch ex As Exception
                MsgBox("record cannot be updated, please provide the valid data")
            End Try
        End If

        con.Close()
    End Sub
End Class