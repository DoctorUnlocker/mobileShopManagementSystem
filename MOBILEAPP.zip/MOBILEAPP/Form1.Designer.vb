﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.signoutbtn = New FontAwesome.Sharp.IconButton()
        Me.databasebtn = New FontAwesome.Sharp.IconButton()
        Me.expensesbtn = New FontAwesome.Sharp.IconButton()
        Me.purchasesbtn = New FontAwesome.Sharp.IconButton()
        Me.salesbtn = New FontAwesome.Sharp.IconButton()
        Me.loginbtn = New FontAwesome.Sharp.IconButton()
        Me.homebtn = New FontAwesome.Sharp.IconButton()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(28, Byte), Integer))
        Me.Panel2.Controls.Add(Me.signoutbtn)
        Me.Panel2.Controls.Add(Me.databasebtn)
        Me.Panel2.Controls.Add(Me.expensesbtn)
        Me.Panel2.Controls.Add(Me.purchasesbtn)
        Me.Panel2.Controls.Add(Me.salesbtn)
        Me.Panel2.Controls.Add(Me.loginbtn)
        Me.Panel2.Controls.Add(Me.homebtn)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(984, 55)
        Me.Panel2.TabIndex = 1
        '
        'signoutbtn
        '
        Me.signoutbtn.Dock = System.Windows.Forms.DockStyle.Right
        Me.signoutbtn.FlatAppearance.BorderSize = 0
        Me.signoutbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.signoutbtn.ForeColor = System.Drawing.Color.White
        Me.signoutbtn.IconChar = FontAwesome.Sharp.IconChar.ShareSquare
        Me.signoutbtn.IconColor = System.Drawing.Color.Red
        Me.signoutbtn.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.signoutbtn.IconSize = 28
        Me.signoutbtn.Location = New System.Drawing.Point(869, 0)
        Me.signoutbtn.Name = "signoutbtn"
        Me.signoutbtn.Size = New System.Drawing.Size(115, 55)
        Me.signoutbtn.TabIndex = 6
        Me.signoutbtn.Text = "SignOut"
        Me.signoutbtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.signoutbtn.UseVisualStyleBackColor = True
        '
        'databasebtn
        '
        Me.databasebtn.Dock = System.Windows.Forms.DockStyle.Left
        Me.databasebtn.FlatAppearance.BorderSize = 0
        Me.databasebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.databasebtn.ForeColor = System.Drawing.Color.White
        Me.databasebtn.IconChar = FontAwesome.Sharp.IconChar.Database
        Me.databasebtn.IconColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.databasebtn.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.databasebtn.IconSize = 28
        Me.databasebtn.Location = New System.Drawing.Point(575, 0)
        Me.databasebtn.Name = "databasebtn"
        Me.databasebtn.Size = New System.Drawing.Size(115, 55)
        Me.databasebtn.TabIndex = 5
        Me.databasebtn.Text = "Database"
        Me.databasebtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.databasebtn.UseVisualStyleBackColor = True
        '
        'expensesbtn
        '
        Me.expensesbtn.Dock = System.Windows.Forms.DockStyle.Left
        Me.expensesbtn.FlatAppearance.BorderSize = 0
        Me.expensesbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.expensesbtn.ForeColor = System.Drawing.Color.White
        Me.expensesbtn.IconChar = FontAwesome.Sharp.IconChar.SortAlphaDownAlt
        Me.expensesbtn.IconColor = System.Drawing.Color.Yellow
        Me.expensesbtn.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.expensesbtn.IconSize = 28
        Me.expensesbtn.Location = New System.Drawing.Point(460, 0)
        Me.expensesbtn.Name = "expensesbtn"
        Me.expensesbtn.Size = New System.Drawing.Size(115, 55)
        Me.expensesbtn.TabIndex = 4
        Me.expensesbtn.Text = "Expenses"
        Me.expensesbtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.expensesbtn.UseVisualStyleBackColor = True
        '
        'purchasesbtn
        '
        Me.purchasesbtn.Dock = System.Windows.Forms.DockStyle.Left
        Me.purchasesbtn.FlatAppearance.BorderSize = 0
        Me.purchasesbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.purchasesbtn.ForeColor = System.Drawing.Color.White
        Me.purchasesbtn.IconChar = FontAwesome.Sharp.IconChar.Paperclip
        Me.purchasesbtn.IconColor = System.Drawing.Color.Fuchsia
        Me.purchasesbtn.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.purchasesbtn.IconSize = 28
        Me.purchasesbtn.Location = New System.Drawing.Point(345, 0)
        Me.purchasesbtn.Name = "purchasesbtn"
        Me.purchasesbtn.Size = New System.Drawing.Size(115, 55)
        Me.purchasesbtn.TabIndex = 3
        Me.purchasesbtn.Text = "Purchases"
        Me.purchasesbtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.purchasesbtn.UseVisualStyleBackColor = True
        '
        'salesbtn
        '
        Me.salesbtn.Dock = System.Windows.Forms.DockStyle.Left
        Me.salesbtn.FlatAppearance.BorderSize = 0
        Me.salesbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.salesbtn.ForeColor = System.Drawing.Color.White
        Me.salesbtn.IconChar = FontAwesome.Sharp.IconChar.Sellsy
        Me.salesbtn.IconColor = System.Drawing.Color.Cyan
        Me.salesbtn.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.salesbtn.IconSize = 28
        Me.salesbtn.Location = New System.Drawing.Point(230, 0)
        Me.salesbtn.Name = "salesbtn"
        Me.salesbtn.Size = New System.Drawing.Size(115, 55)
        Me.salesbtn.TabIndex = 2
        Me.salesbtn.Text = "Sales"
        Me.salesbtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.salesbtn.UseVisualStyleBackColor = True
        '
        'loginbtn
        '
        Me.loginbtn.Dock = System.Windows.Forms.DockStyle.Left
        Me.loginbtn.FlatAppearance.BorderSize = 0
        Me.loginbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.loginbtn.ForeColor = System.Drawing.Color.White
        Me.loginbtn.IconChar = FontAwesome.Sharp.IconChar.Lock
        Me.loginbtn.IconColor = System.Drawing.Color.Lime
        Me.loginbtn.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.loginbtn.IconSize = 28
        Me.loginbtn.Location = New System.Drawing.Point(115, 0)
        Me.loginbtn.Name = "loginbtn"
        Me.loginbtn.Size = New System.Drawing.Size(115, 55)
        Me.loginbtn.TabIndex = 1
        Me.loginbtn.Text = "Login"
        Me.loginbtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.loginbtn.UseVisualStyleBackColor = True
        '
        'homebtn
        '
        Me.homebtn.Dock = System.Windows.Forms.DockStyle.Left
        Me.homebtn.FlatAppearance.BorderSize = 0
        Me.homebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.homebtn.ForeColor = System.Drawing.Color.White
        Me.homebtn.IconChar = FontAwesome.Sharp.IconChar.Home
        Me.homebtn.IconColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.homebtn.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.homebtn.IconSize = 28
        Me.homebtn.Location = New System.Drawing.Point(0, 0)
        Me.homebtn.Name = "homebtn"
        Me.homebtn.Size = New System.Drawing.Size(115, 55)
        Me.homebtn.TabIndex = 0
        Me.homebtn.Text = "Home"
        Me.homebtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.homebtn.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 55)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(984, 462)
        Me.Panel1.TabIndex = 2
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(984, 517)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "Mobile Shop Management System"
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel2 As Panel
    Friend WithEvents signoutbtn As FontAwesome.Sharp.IconButton
    Friend WithEvents databasebtn As FontAwesome.Sharp.IconButton
    Friend WithEvents expensesbtn As FontAwesome.Sharp.IconButton
    Friend WithEvents purchasesbtn As FontAwesome.Sharp.IconButton
    Friend WithEvents salesbtn As FontAwesome.Sharp.IconButton
    Friend WithEvents loginbtn As FontAwesome.Sharp.IconButton
    Friend WithEvents homebtn As FontAwesome.Sharp.IconButton
    Friend WithEvents Panel1 As Panel
End Class
